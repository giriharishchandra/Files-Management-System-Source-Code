<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
	header("location:login.php");
	die();
}

// Unset all session variables
session_unset();


// Destroy the session
session_destroy();

header("location:login.php");
die();

?>