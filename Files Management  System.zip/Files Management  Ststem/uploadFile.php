<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
	header("location:login.php");
	die();
}
?>
<?php
$msg="";
$msg1="";

 $id1=$_SESSION['user_id'];
if(isset($_POST['Btn1'])){
    $faculty=$_POST["stream"];  //it takes the name of file given in input type title.
    $subject=$_POST["personContact"];
    $upld=$_POST["stream1"];
    $filename=$_FILES["fileName"]["name"];   //"filename" is name of input-type file  && "name" gives the name of file contained by $_FILES.
    $tempfile=$_FILES["fileName"]["tmp_name"];  //"filename" is name of input-type file  && "tmp_name" gives the temporary name of file contained by $_FILES.
    $folder='files/'.basename($filename);   //"uploadedFiles" is the folder name where images will be stored and ".$filename" contains name of file i.e ###.jpg, #####.pdf etc.
    // OR  $folder='uploadedFiles/'.$filename;  

    // $sql1=mysqli_query($con,"insert into login(email,name,date,password,school,university)
    //  values('$email','$name','$date','$password','$school','$university')");

    $filesize=$_FILES["fileName"]["size"];
    if($filesize>1048576){
        $msg="file less than 10MB alloweded.";
    }
    else{

    $sql=mysqli_query($con,"INSERT INTO userdetails(f_id,subject1,faculty,uploadby,file1)
     VALUES($id1,'$subject','$faculty','$upld','$filename')"); 
    move_uploaded_file($tempfile,$folder);
    header("location:profile.php");
}
}
?>
<?php
if(isset($_POST['Btn2'])){
    $filename1=$_FILES["fileName1"]["name"];   //"filename" is name of input-type file  && "name" gives the name of file contained by $_FILES.
    $tempfile1=$_FILES["fileName1"]["tmp_name"];  //"filename" is name of input-type file  && "tmp_name" gives the temporary name of file contained by $_FILES.
    $folder1='photos/'.basename($filename1);

    $filesize1=$_FILES["fileName1"]["size"];
    if($filesize1>1048576){
        $msg1="file less than 10MB alloweded.";
    }
    else{
    $sql1=mysqli_query($con,"select photo from login1 where id=$id1");
    $pto=mysqli_fetch_assoc($sql1);
    $val=$pto['photo'];
    $lnk="photos/".$val;
    // unlink($filename)
    unlink($lnk);
    $sql2=mysqli_query($con,"UPDATE login1 SET photo='$filename1' where id=$id1");
    move_uploaded_file($tempfile1,$folder1);
    header("location:profile.php");
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>uploadFiles</title>
    <link rel="stylesheet" href="update.css">
</head>
<body>
<div class="wrapper" style="height: 400px;">
        <center>
            <h2 class="header">UPLOAD FILES</h2>
        </center>
        <form action="" enctype="multipart/form-data" method="post">
            <label>Faculty:</label><br>
            <select name="stream" id="streamId" class="input1" required>
                <optgroup label="FACULTY">
                    <option value="OTHERS">OTHERS</option>
                    <option value="BBA">BBA</option>
                    <option value="BBS">BBS</option>
                    <option value="BSC">BSC</option>
                    <option value="BE.CIVIL">BE.CIVIL</option>
                    <option value="BE.IT">BE.IT</option>
                    <option value="BE.COMPUTER">BE.COMPUTER</option>
                    <option value="BE.ELECTRONIC">BE.ELECTRONIC</option>
                    <option value="LAW">LAW</option>
                    <option value="MBBS">MBBS</option>
                </optgroup>
            </select>
            <br><br>
            <label>STATUS:</label><br>
            <select name="stream1" id="streamId" class="input1" required>
                <optgroup label="STATUS">
                    <option value="PUBLIC">PUBLIC</option>
                    <option value="PRIVATE">PRIVATE</option>
                </optgroup>
            </select>
            <br><br>
            <label for="">Subject:</label><br>
            <input type="text" class="input1" name="personContact" placeholder="Subject" required>
            <br><br>
            <label for="">Notes:</label><br>
            <input type="file" class="input1" name="fileName" required><br>
            <center style="height: 5px;"><?php echo $msg; ?></center>
            <br>
            <button class="btn1" name="Btn1">Submit</button>
        </form>
        <br>
        <form action="" enctype="multipart/form-data" method="post">
            <label for="">Profile Photo:</label><br>
            <input type="file" class="input1" name="fileName1" required><br>
            <center style="height: 5px;"><?php echo $msg1; ?></center>
            <br>
            <button class="btn1" name="Btn2">Submit</button>
        </form>
</body>
</html>