
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cover Page</title>
    <style type="text/css">
    	*{
    		margin: 0px;
    		padding: 0px;
    	}
    	.divi{
    		margin-top: 20px;
    		margin-bottom: 20px;
    	}
    	.div0{
    		display: flex;
    	}
    	.div1{
    		margin: 15px 20px;
    		border-radius: 5px;
    		height: 460px;
    		width: 25%;
    	}
    	.div2{
    		padding-top: 50px;
    		padding-left: 30px;
    		max-width: 65%;
    	}
    	.div2 h2{
    		margin-top: 50px;
    	}
    	.div1 p{
    		font-size: 20px;
    	}
    	#logo{
    		color: red;
    		background-color: white;
    		height: 150px;
    		width: 150px;
    		border-radius: 50%;
    		font-size: 30px;
    	}

    </style>
</head>
<body style="background-color: blue;">
    <center>
    	<div class="divi">
        	<h1 style="color: white;">
            	FILES MANAGEMENT SYSTEM
        	</h1>
        </div>
        <hr>
    </center>
    <div class="div0">
    <div class="div1" style="background-color: green; padding: 10px;">
        <center>
        	<div style="height: 200px;">
        	<p style="color: red; margin: 20px;">Click Below to Login!</p>
        	<a href="logIn.php" style="color: white; margin: 30px;">LOGIN</a>
        	</div>
        	<div id="logo">
        		<h1 style="padding-top: 40px;">FMS</h1>
        	</div>
       	</center>
    </div>
    <div class="div2">
    	<h2 style="color: white;">About our Services:</h2>
    	<p style="color: white;">
    		Our Files Management System is designed to be intuitive, versatile, and adaptable to various needs. Whether you're a student taking lecture notes, a professional organizing meeting minutes, or someone simply trying to keep track of your thoughts and ideas, our system is here to simplify your life. Some of the key features of our system include:
    	<br>
        Easy Note Capture: Seamlessly record your thoughts, ideas, and information through multiple input methods, including typing, voice, and image recognition.
        <br>
        Efficient Organization: Categorize, tag, and archive your notes for easy retrieval and reference. Our advanced search capabilities ensure you can find what you need when you need it.
        <br>
        Collaboration: Share and collaborate on notes with colleagues, classmates, or team members, fostering productivity and teamwork.
        <br>
        Security and Privacy: We prioritize the security of your data. Rest assured that your notes are kept safe and private with robust encryption and access control features.
    </p>
    </div>
    </div>
</body>
</html>