<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help And Support</title>
    <link rel="stylesheet" href="helpAndSupport.css">
</head>
<body>
    <center>
        <h2>
            Help And Support
        </h2>
        <div>
            <h3>
                Help Center
            </h3>
            <p>
                The Files Management System Help Center is a comprehensive online resource where you can find answers to common questions and solutions to common problems. 
                <br>
                It covers a wide range of topics related to using Files Management System and its features.
            </p>
            <h3>
                Community Support
            </h3>
            <p>
                Files Management System has a user community where you can post questions, seek advice, and share experiences with other users.
                <br>
                The community is divided into various sections based on different topics and issues.
            </p>
            <h3>
                Report a Problem
            </h3>
            <p>
                Files Management System allows users to report problems or issues with specific content or features.
                <br>
                You can usually report problrms in our facebook page. This is particularly useful if you encounter abusive or harmful content.
            </p>
            <h3>
                Accessibility Support
            </h3>
            <p>
                Files Management System provides support for users with disabilities.
                <br>
                They have resources and features to improve accessibility, and you can reach out for specific accessibility-related support.
            </p>
        </div>
    </center>
</body>
</html>