<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="privacy.css">
</head>
<body>
    <center>
        <h2>
        Privacy Policy
        </h2>
        <div>
            <h3> 
                Introduction
            </h3>
            <p>
                Welcome to our File Management System! We are committed to protecting your privacy and
                 safeguarding your personal information. This Privacy Policy outlines how we collect, use, 
                 and protect your data when you use our File Management System. 
            </p>
            <h3>
                Information We Collect
            </h3>
            <p>
                We collect information you provide when you create an account, including your name, email address, and password.
                
                Any files you upload to our system are stored securely. We do not access or use the content of your files for
                any purpose other than providing our service to you.
            </p>
            <h3>
                Data Security
            </h3>
            <p>
                We employ industry-standard security measures to protect your data from unauthorized access, disclosure, alteration, and destruction.
                Access to your account is protected by a password you create, so please ensure its confidentiality.
            </p>
            <h3>
                Children's Privacy
            </h3>
            <p>
                Our services are not intended for children under 13 years of age. We do not knowingly collect personal information from children.
            </p>
            <h3>
                Contact Us
            </h3>
            <p>
                If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at Facebook, Instragram.
                By using our Files Management System, you agree to the terms outlined in this Privacy Policy. Please review this policy periodically for updates.
            </p>
        </div>
    </center>
</body>
</html>