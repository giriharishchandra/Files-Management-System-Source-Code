<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
	header("location:login.php");
	die();
}
?>
<?php
$user_id = $_SESSION['user_id'];

if(isset($_POST['submit'])){
    $selec=$_POST['stream'];
    $query = mysqli_query($con,"select * from userdetails where faculty='$selec' ORDER by id DESC");
    $num=mysqli_num_rows($query);
}
else{
    $query = mysqli_query($con,"select * from userdetails where uploadby!='PRIVATE' ORDER by id DESC");
    $num=mysqli_num_rows($query);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
    <link rel="stylesheet" href="body.css" type="text/css">
    <style>
        @media (max-width: 455px){
        #selectId{
         width: 450px;
        }
        .navContainer{
         width: 430px;
        }
        .tableContainer{
         width: 450px;  
        }
    }

    </style>
</head>
<body style="background-color: green">
   <?php
    include('navBar.html');
   ?>
      <div style=" background-color: aquamarine;" id="selectId">
        <center>
            <form action="" method="post">
                <label>FACULTY:</label>
                <select name="stream" id="streamId" class="input1">
                    <optgroup label="FACULTY">
                        <option value="BBA">BBA</option>
                        <option value="BBS">BBS</option>
                        <option value="BSC">BSC</option>
                        <option value="BE.CIVIL">BE.CIVIL</option>
                        <option value="BE.IT">BE.IT</option>
                        <option value="BE.COMPUTER">BE.COMPUTER</option>
                        <option value="BE.ELECTRONIC">BE.ELECTRONIC</option>
                        <option value="LAW">LAW</option>
                        <option value="MBBS">MBBS</option>
                        <option value="OTHERS">OTHERS</option>
                    </optgroup>
                </select>
                <button name="submit" style="background-color: rgb(215, 149, 244); margin: 10px; border-radius: 5px; width: 60px;">Submit</button>
            </form>
        </center>
    </div>
    <div class="tableContainer">
        <table class="tableClass">
            <thead class="tableHeadContainer">
                <tr>
                    <th id="tablehead1" class="tablehead">FACULTY</th>
                    <th id="tablehead2" class="tablehead">UPLOAD BY</th>
                    <th id="tablehead3" class="tablehead">SUBJECT NAME</th>
                    <th id="tablehead4" class="tablehead">FILE</th>
                </tr>
            </thead>
            <tbody class="tableBodyContainer">
                <?php
                  for($i=1;$i<=$num;$i++){
                $row =mysqli_fetch_array($query);
                $nid=$row['f_id'];
                $sql=mysqli_query($con,"select name1 from login1 where id=$nid");
                $row1=mysqli_fetch_assoc($sql);

                ?>
                <tr>
                    <td id="tablehead1" class="tabledata"><?php echo $row['faculty']; ?></td>
                    <td id="tabledata2" class="tabledata"><?php echo $row1['name1']; ?></td>
                    <td id="tabledata3" class="tabledata"><?php echo $row['subject1']; ?></td>
                    <td id="tablehead4" class="tabledata"><center><a id="tabledataAnchor" href="download.php? id=<?php echo $row['id']; ?>">download</a></center></td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>