<?php
$con= new mysqli("localhost","root","","logindb");

if($con->connect_error){
    die("connection failed:".$con->connect_error);
}

$msg='';

if (isset($_POST['submit'])) {

    $name=$_POST['txt'];
    $email=$_POST['email'];
    $university=$_POST['uni_txt'];
    $school=$_POST['sch_txt'];
    $date=$_POST['date'];
    $password=$_POST['pswd'];
    $sql = mysqli_query($con,"select email from login1 where email='$email'");
    $result= mysqli_fetch_assoc($sql);
    if($result['email']==$email){
        $msg='Duplicate email not valid !';
    }
    else{
    $sql1=mysqli_query($con,"insert into login1(email,name1,date1,password1,school,university) values('$email','$name','$date','$password','$school','$university')");
    header("location:logIn.php");
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>signup</title>
    <link rel="stylesheet" type="text/css" href="Slidestyle.css">
</head>

<body>
    <div class="main">
        <input type="checkbox" id="chk" aria-hidden="true">

        <div class="signup">
            <form action="" method="post" >
                <label for="chk" aria-hidden="true">Sign up</label>
                <input type="text" id="textIdSignup" name="txt" placeholder="Name" required="">
                <input type="email" id="emailIdSignup" name="email" placeholder="Email" required="" onkeyup="validateEmail()">
                <center><span id="spanIdSignup" style="color: white"><?php echo $msg;?></span></center> 
                <input type="text" id="university" name="uni_txt" placeholder="University" required="">
                <input type="text" id="school" name="sch_txt" placeholder="School" required="">
                <input type="date" id="dateIdSignup" name="date" placeholder="" required="">
                <input type="password" id="passwordIdSignup" name="pswd" placeholder="Password" required="">
                <span id="spanIdPassword"></span>
                <button name="submit">register up</button>

            </form>
        </div>

<script>
	var emailVal=document.getElementById("emailIdSignup");
	var emailSpan=document.getElementById("spanIdSignup");
	function validateEmail(){
		if(!emailVal.value.match(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)){
			emailSpan.innerHTML="Please Enter Valid email";
			return false;
		}
		emailSpan.innerHTML="";
		return true;
	}
</script>

</body>

</html>