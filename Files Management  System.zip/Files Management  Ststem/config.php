<?php
session_start();


$con= new mysqli("localhost","root","","logindb");

if($con->connect_error){
    die("connection failed:".$con->connect_error);
}

?>


<!-- http://localhost/signup/config.php -->