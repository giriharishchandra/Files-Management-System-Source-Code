<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
    die();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="aboutUs.css">
</head>
<body>
    <center>
        <h2>
            About Us
        </h2>
        <div>
            <h3>
                Our Mission
            </h3>
            <p>
                At the Files Management System, our mission is to empower individuals and organizations to streamline their note-taking, knowledge management, and information organization processes.
                <br>
                We understand the importance of effective files management in today's information-rich world, and we are committed to providing innovative solutions that enhance productivity and knowledge retention.
            </p>
            <h3>
                Who We Are
            </h3>
            <p>
                We are a dedicated team of professionals who are passionate about simplifying the way people capture, organize, and access information.
                <br>
                Our journey began with a simple realization: notes are the building blocks of knowledge, and managing them efficiently can make a significant difference in personal and professional growth.
            </p>
            <h3>
                What We Offer
            </h3>
            <p>
                Our Files Management System is designed to be intuitive, versatile, and adaptable to various needs. Whether you're a student taking lecture notes, a professional organizing meeting minutes, or someone simply trying to keep track of your thoughts and ideas, our system is here to simplify your life. Some of the key features of our system include:
                <br>
                Easy Note Capture: Seamlessly record your thoughts, ideas, and information through multiple input methods, including typing, voice, and image recognition.
                <br>
                Efficient Organization: Categorize, tag, and archive your notes for easy retrieval and reference. Our advanced search capabilities ensure you can find what you need when you need it.
                <br>
                Collaboration: Share and collaborate on notes with colleagues, classmates, or team members, fostering productivity and teamwork.
                <br>
                Security and Privacy: We prioritize the security of your data. Rest assured that your notes are kept safe and private with robust encryption and access control features.
                <br>
                Sync Across Devices: Access your notes anytime, anywhere, on various devices, ensuring your information is always at your fingertips.

                Our Values
                <br><br><br>
                User-Centric: We put our users at the center of everything we do, constantly seeking feedback to improve our system and enhance user experience.
                <br>
                Innovation: We are committed to staying at the forefront of technology and information management trends, continually innovating to provide cutting-edge solutions.
                <br>
                Simplicity: We believe that complex problems can have simple solutions. Our platform is designed with ease of use in mind, ensuring that anyone can harness its power.
            </p>
            <h3>
                Future Vision
            </h3>
            <p>
                As we look to the future, our commitment remains unwavering.
                <br>
                We envision a world where individuals and organizations can effortlessly manage their knowledge, enabling them to be more productive, creative, and informed. We will continue to evolve our Notes Management System, incorporating new features and technologies to meet the evolving needs of our users.
            </p>
        </div>
    </center>
</body>
</html>