<?php
include('config.php');

if (!isset($_SESSION['user_id'])) {
	header("location:login.php");
	die();
}
?>
<?php
$user_id = $_SESSION['user_id'];
$email=$_SESSION['user_email'];

$query1= mysqli_query($con,"select * from login1 where id=$user_id && email='$email'");
$num=mysqli_fetch_array($query1);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body style="background-color: white">
    <?php
    include('navBar.html');
    ?>
<div class="wrapperDiv">

<div class="profileDiv">
    <img src="photos/<?php echo $num['photo']; ?>" alt="photo" style="background-color: blue">
</div>
<div class="detailDiv" style="padding: 10px;">
    <center>
        <a style="color: blue;" href="uploadFile.php">UPLOAD FILES</a>
    </center>
</div>
<div class="detailDiv">
    <h2>About</h2>
    <p class="name">Name:<span><?php echo $num['name1']; ?></span></p>
    <p class="gmail">Gmail:<span><?php echo $num['email']; ?></span></p>
    <p class="birthDate">Birth date:<span><?php echo $num['date1']; ?></span></p>
    <p class="school">School:<span><?php echo $num['school']; ?></span></p>
    <p class="university">University:<span><?php echo $num['university']; ?></span></p>
    <p class="submitButton"><center><a class="othersAnchor" href="profileUpdate.php">Update</a></center></p>

    <!-- the image can be updated from update of About.  -->

</div>
<div class="detailDiv">
    <h2>Login Details</h2>
    <p class="name">Gmail:<span><?php echo $num['email']; ?></span></p>
    <p class="gmail">Password:<span><?php echo $num['password1']; ?></span></p>
    <p class="securityButton"><a class="othersAnchor" href="profileUpdate.php">Update</a></p>
</div>
<div class="othersDiv">
    <h2>Others</h2>
    <p class="privacyPolicy others"><a class="othersAnchor" href="privacyPolicy.php">Privacy Policy</a></p>
    <p class="AboutUs others"><a class="othersAnchor" href="aboutUs.php">About us</a></p>
    <p class="help others"><a class="othersAnchor" href="helpAndSupport.php">Help & Support</a></p>
    <form action="logOut.php" method="post">
    <p class="help others"></p><button id="logout1" name="logout10">LogOut</button></p>
    </form>
</div>
</div>
</body>
</html>