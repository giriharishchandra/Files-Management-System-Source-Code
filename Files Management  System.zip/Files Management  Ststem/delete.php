<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
	header("location:login.php");
	die();
}
?>
<?php
    $id = $_GET['id'];
    $sql1=mysqli_query($con,"select file1 from userdetails where id=$id");
    $pto=mysqli_fetch_assoc($sql1);
    $val=$pto['file1'];
    $lnk="files/".$val;
    unlink($lnk);

    $sql2=mysqli_query($con,"delete from userdetails where id=$id");
    header("location:upload.php");

?>