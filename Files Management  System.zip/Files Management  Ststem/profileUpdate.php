<?php
include('config.php');
if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
    die();
}
?>

<?php
$id1=$_SESSION['user_id'];

$sql1=mysqli_query($con,"select * from login1 where id=$id1");
$result=mysqli_fetch_assoc($sql1);

if(isset($_POST['Btn1'])){
    $name=$_POST['personName'];
    $dt=$_POST['dateOfBirth'];
    $pas=$_POST['personPassword'];
    $scool=$_POST['schoolName'];
    $unicty=$_POST['universityName'];

    $sql=mysqli_query($con,"update login1 set name1='$name' where id=$id1");

    $sql2=mysqli_query($con,"UPDATE login1 SET date1='$dt', password1='$pas', school='$scool', university='$unicty' where id=$id1");
    header("location:profile.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Update</title>
    <link rel="stylesheet" href="update1.css">
</head>

<body>
    <div class="wrapper">
        <center>
            <h2 class="header">Update Details</h2>
        </center>
        <form action="" enctype="multipart/form-data" method="post">
            <br><br>
            <label style="color: blue;">Enter your new Details that you want to Update and Submit.</label>
            <br><br><br>

            <label for="">Name:</label><br>
            <input type="text" class="input1" name="personName" value="<?php echo $result['name1']; ?>"><br><br>
           
          
            <label for="">Date:</label><br>
            <input type="date" class="input1" name="dateOfBirth" value="<?php echo $result['date1']; ?>"><br><br>
           

            <label for="">School:</label><br>
            <input type="text" class="input1" name="schoolName" value="<?php echo $result['school']; ?>"><br><br>
            

            <label for="">University:</label>
            <input type="text" class="input1" name="universityName" value="<?php echo $result['university']; ?>"><br><br>

            <label style="color: blue;">Enter New password if you want to change password.</label><br><br>

            <label for="">Password:</label><br>
            <input type="text" class="input1" name="personPassword" value="<?php echo $result['password1']; ?>"><br><br><br>

            <button class="btn1" name="Btn1">Submit</button>
        </form>
    </div>
</body>

</html>