<?php
include('config.php');

$msg="";
  
if (isset($_POST['submit'])) {

  $email = mysqli_real_escape_string($con,$_POST['email']);
  $password = mysqli_real_escape_string($con,$_POST['pswd']);

  $sql = mysqli_query($con,"select * from login1 where email='$email' && binary password1='$password'");

  $num=mysqli_num_rows($sql);
  if ($num>0) {
    $row=mysqli_fetch_assoc($sql);
    $_SESSION['user_id']=$row['id'];
    $_SESSION['user_email']=$row['email'];
	$_SESSION['user_name']=$row['name1'];
    header("location:index.php");
  }
  else{
    $msg="Please Enter Valid Details !";
  }
}

?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="Slidestyle.css">
	<script src="sinUp&logIn.js"></script>
</head>

<body>
	<div class="login">
		<form action="" method="post">
			<label for="chk" aria-hidden="true">Login</label>
			<input type="email" id="emailIdLogin" name="email" placeholder="Email" required="" onkeyup="validateEmail()">
			 <center><span id="spanIdLogin" style="color: white;"></span></center>
			<input type="password" name="pswd" placeholder="Password" required="">
			<center><span id="spanIdLogin"  style="color: red;"><?php echo $msg;?></span></center>
			<button name="submit">Login</button>
			<div class="centre">
			<center style="color:white;">For Signup!<a style="color:blue;" href="signUp.php">Click Here!</a></center>
			</div>
		</form>
	</div>
	</div>
<script>
	var emailVal=document.getElementById("emailIdLogin");
	var emailSpan=document.getElementById("spanIdLogin");
	function validateEmail(){
		if(!emailVal.value.match(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)){
			emailSpan.innerHTML="Please Enter Valid email";
			return false;
		}
		emailSpan.innerHTML="";
		return true;
	}
</script>

</body>

</html>